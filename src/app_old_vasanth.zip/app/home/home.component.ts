import { Component, OnInit } from '@angular/core';
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import { ServiceAPIService } from '../service-api.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  duration: any;
  getSightingsInfo: any;

  activeCount: any;
  exposureCount: any;
  daysCount: any;
  percentageInfo: any;

  closedCount: any;
  exposureClosedCount: any;
  closedCountPercentages: any;

  constructor(private apiService: ServiceAPIService) { }

  ngOnInit(): void {
    this.onValChange('Year');

  }

  onValChange(value) {
    this.duration = value;
    let obj =
    {
      "ChartType": this.duration
    }
    this.apiService.getOpenCloseTrendInfo(obj).subscribe((res: any) => {
      this.renderChar(res.getOpenCloseTrendInfo);
    })

    this.apiService.getOpenSightingsByDomainAndExposure().subscribe((res: any) => {
      console.log(res.getSightingsInfo);
      this.getSightingsInfo = res.getSightingsInfo;
      this.openSightingTrend(this.getSightingsInfo);
    })

    this.apiService.getActiveCount().subscribe((res: any) => {
      this.activeCount = res.activeCount[0].activeCount;
      this.exposureCount = res.exposureCount;
      this.daysCount = res.daysCount;
      this.percentageInfo = res.percentageInfo;
      console.log(res.percentageInfo);
      console.log(res);
      // this.getSightingsInfo = res.getSightingsInfo;
      // this.openSightingTrend(this.getSightingsInfo);

      this.exposureBarChat();
      this.exposurePieChat();
      this.closedExposurePie();
    })

    this.apiService.getClosedCount().subscribe((res : any)=>{
      console.log(res);
      this.closedCount = res.closedCount[0].closedCount;
      this.exposureClosedCount = res.exposureClosedCount;
      this.closedCountPercentages = res.closedCountPercentages;
     
    })

  }



  exposureBarChat() {

    am4core.useTheme(am4themes_animated);
    am4core.options.autoSetClassName = true;
    am4core.options.commercialLicense = true;

    let chart = am4core.create("chartdivbar", am4charts.XYChart);

    // Add data
    chart.data = this.daysCount;
    // Create axes

    let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
    categoryAxis.dataFields.category = "daysRange";
    categoryAxis.renderer.grid.template.location = 0;
    categoryAxis.renderer.minGridDistance = 30;

    // categoryAxis.renderer.labels.template.adapter.add("dy", function(dy, target) {
    //   if (target.dataItem && target.dataItem.index & 2 == 2) {
    //     return dy + 25;
    //   }
    //   return dy;
    // });

    let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());

    // Create series
    let series = chart.series.push(new am4charts.ColumnSeries());
    series.dataFields.valueY = "daysCount";
    series.dataFields.categoryX = "daysRange";
    series.name = "daysCount";
    series.columns.template.tooltipText = "{categoryX}: [bold]{valueY}[/]";
    series.columns.template.fillOpacity = .8;

    let columnTemplate = series.columns.template;
    columnTemplate.strokeWidth = 2;
    columnTemplate.strokeOpacity = 1;

    //chart.scrollbarX = new am4core.Scrollbar();

  }

  closedExposurePie() {
    ///let container = am4core.create("closeExposurepie", am4core.Container);
    am4core.useTheme(am4themes_animated);
    am4core.options.autoSetClassName = true;
    am4core.options.commercialLicense = true;

    // Create chart instance
    let chart = am4core.create("closeExposurepie", am4charts.PieChart);
    am4core.useTheme(am4themes_animated);
    chart.hiddenState.properties.opacity = 0;

    chart.data = this.closedCountPercentages;
    chart.radius = am4core.percent(70);
    chart.innerRadius = am4core.percent(40);
    chart.startAngle = 180;
    chart.endAngle = 360;

    let series = chart.series.push(new am4charts.PieSeries());
    series.dataFields.value = "percentage";
    series.dataFields.category = "names";

    series.slices.template.cornerRadius = 10;
    series.slices.template.innerCornerRadius = 7;
    series.slices.template.draggable = true;
    series.slices.template.inert = true;
    series.alignLabels = false;

    series.hiddenState.properties.startAngle = 90;
    series.hiddenState.properties.endAngle = 90;
    //chart.legend = new am4charts.Legend();
  }

  exposurePieChat() {
    am4core.useTheme(am4themes_animated);
    am4core.options.autoSetClassName = true;
    am4core.options.commercialLicense = true;

    // Create chart instance
    let chart = am4core.create("chartdivpie", am4charts.PieChart);
    am4core.useTheme(am4themes_animated);
    chart.hiddenState.properties.opacity = 0;

    chart.data = this.percentageInfo;
    chart.radius = am4core.percent(70);
    chart.innerRadius = am4core.percent(40);
    chart.startAngle = 180;
    chart.endAngle = 360;

    let series = chart.series.push(new am4charts.PieSeries());
    series.dataFields.value = "percentage";
    series.dataFields.category = "names";

    series.slices.template.cornerRadius = 10;
    series.slices.template.innerCornerRadius = 7;
    series.slices.template.draggable = true;
    series.slices.template.inert = true;
    series.alignLabels = false;

    series.hiddenState.properties.startAngle = 90;
    series.hiddenState.properties.endAngle = 90;
    //chart.legend = new am4charts.Legend();
  }

  renderChar(dataOpenCloseTrendInfo) {

    /* Chart code */
    // Themes begin
    am4core.useTheme(am4themes_animated);
    am4core.options.autoSetClassName = true;
    am4core.options.commercialLicense = true;
    // Themes end

    let chart = am4core.create('chartdiv', am4charts.XYChart)
    //chart.colors.step = 2;
    chart.colors.list = [
      am4core.color("#c6c6c6"),
      am4core.color("#ffd688"),
      am4core.color("#aac6e7"),
      am4core.color("#aace9a"),
      /* am4core.color("#FFC75F"), */
      am4core.color("#F9F871")
    ];

    let xAxis = chart.xAxes.push(new am4charts.CategoryAxis())
    xAxis.dataFields.category = 'chartType'
    xAxis.renderer.cellStartLocation = 0.03
    xAxis.renderer.cellEndLocation = 0.97
    xAxis.renderer.grid.template.location = 0;
    //xAxis.title.text = "[bold]" + this.duration;
    xAxis.renderer.minGridDistance = 20;
    xAxis.renderer.labels.template.rotation = 290;
    xAxis.renderer.labels.template.fill = am4core.color("#000000");
    let label = xAxis.renderer.labels.template;
    label.truncate = true;
    label.maxWidth = 120;
    label.tooltipText = "{category}";
    label.fontSize = 12;

    let yAxis = chart.yAxes.push(new am4charts.ValueAxis());
    yAxis.min = 0;
    yAxis.title.text = '[bold] Submitted/Closed Counts';
    yAxis.renderer.labels.template.fill = am4core.color("#000000");
    yAxis.renderer.labels.template.fontSize = 12;
    yAxis.renderer.minGridDistance = 20;

    let valueAxis2 = chart.yAxes.push(new am4charts.ValueAxis());
    valueAxis2.title.text = "[bold] Cumulative Counts";
    valueAxis2.renderer.opposite = true;
    valueAxis2.min = 0;
    valueAxis2.renderer.labels.template.fill = am4core.color("#000000");
    valueAxis2.renderer.labels.template.fontSize = 12;
    valueAxis2.renderer.minGridDistance = 20;


    function createSeries(value: any, name: any) {
      let series = chart.series.push(new am4charts.ColumnSeries())
      series.dataFields.valueY = value
      series.dataFields.categoryX = 'chartType'
      series.name = name
      series.tooltipText = "[bold]{name}[/]\n[font-size:14px]{categoryX}: {valueY}";
      series.events.on("hidden", arrangeColumns);
      series.events.on("shown", arrangeColumns);

      let bullet = series.bullets.push(new am4charts.LabelBullet())
      bullet.interactionsEnabled = false
      bullet.dy = 20;
      bullet.label.text = '{valueY}'
      bullet.label.fill = am4core.color('#000000')

      return series;
    }

    chart.data = dataOpenCloseTrendInfo;

    createSeries('submittedCount', 'Submitted Counts');
    createSeries('closedCount', 'Closed Counts');
    //createSeries('defect', 'Defect');

    /*    createSeries('implementedtoverified', 'Implemented to verified');
       createSeries('verifiedtoComplete', 'Verified to complete'); */

    function arrangeColumns() {

      let series = chart.series.getIndex(0);

      let w = 1 - xAxis.renderer.cellStartLocation - (1 - xAxis.renderer.cellEndLocation);
      if (series.dataItems.length > 1) {
        let x0 = xAxis.getX(series.dataItems.getIndex(0), "categoryX");
        let x1 = xAxis.getX(series.dataItems.getIndex(1), "categoryX");
        let delta = ((x1 - x0) / chart.series.length) * w;
        if (am4core.isNumber(delta)) {
          let middle = chart.series.length / 2;

          let newIndex = 0;
          chart.series.each(function (series) {
            if (!series.isHidden && !series.isHiding) {
              series.dummyData = newIndex;
              newIndex++;
            }
            else {
              series.dummyData = chart.series.indexOf(series);
            }
          })
          let visibleCount = newIndex;
          let newMiddle = visibleCount / 2;

          chart.series.each(function (series) {
            let trueIndex = chart.series.indexOf(series);
            let newIndex = series.dummyData;

            let dx = (newIndex - trueIndex + middle - newMiddle) * delta

            series.animate({ property: "dx", to: dx }, series.interpolationDuration, series.interpolationEasing);
            series.bulletsContainer.animate({ property: "dx", to: dx }, series.interpolationDuration, series.interpolationEasing);
          })
        }
      }
    }



    function createTraigeLineSeries(value: any, name: any) {

      var lineSeriesTA = chart.series.push(new am4charts.LineSeries());
      lineSeriesTA.name = name;
      lineSeriesTA.dataFields.valueY = value;
      // lineSeriesTA.id = 'g3';
      lineSeriesTA.dataFields.categoryX = "chartType";

      // lineSeriesTA.stroke = am4core.color("#2196f3"); // blue
      lineSeriesTA.strokeWidth = 2;
      lineSeriesTA.propertyFields.strokeDasharray = "lineDash";
      lineSeriesTA.tooltip.label.textAlign = "middle";
      //lineSeriesTA.numberFormatter.numberFormat = "#'%'";
      /*  lineSeriesTA.tensionX = 0.8;
       lineSeriesTA.showOnInit = true; */

      var bulletTA = lineSeriesTA.bullets.push(new am4charts.Bullet());
      // bulletTA.fill = am4core.color("#2196f3"); // tooltips grab fill from parent by default
      // bullet.tooltipText = "[#fff font-size: 15px]{name} in {categoryX}:\n[/][#fff font-size: 20px]{valueY}[/] [#fff]{additional}[/]"
      bulletTA.tooltipText = "[#fff font-size: 15px]{categoryX} : [/][#fff font-size: 15px]{valueY}[/] [#fff]{additional}[/]";
      var circleTA = bulletTA.createChild(am4core.Circle);
      circleTA.radius = 4;
      circleTA.fill = am4core.color("#fff");
      circleTA.strokeWidth = 2;

      var valueLabelTA = lineSeriesTA.bullets.push(new am4charts.LabelBullet());
      valueLabelTA.label.text = "{valueY}";
      valueLabelTA.label.fontSize = 12;
      valueLabelTA.label.dy = 0;
      valueLabelTA.label.dx = -20;


      let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
      /*  if (chart.yAxes.indexOf(valueAxis) != 0) {
         valueAxis.syncWithAxis = chart.yAxes.getIndex(0);
       } */
      valueAxis.min = 0;
      valueAxis.renderer.opposite = true;
      valueAxis.renderer.grid.template.disabled = true;
      valueAxis.title.text = '[bold] Triage latency (in days)';
      valueAxis.renderer.labels.template.fill = am4core.color("#000000");
      valueAxis.renderer.labels.template.fontSize = 12;
      valueAxis.renderer.line.strokeOpacity = 1;
      valueAxis.renderer.line.strokeWidth = 1;
      valueAxis.renderer.line.stroke = am4core.color("#e91e63");
      valueAxis.renderer.labels.template.fill = am4core.color("#e91e63");

    }

    function TraigeLineSeries() {

      let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
      /*  if (chart.yAxes.indexOf(valueAxis) != 0) {
         valueAxis.syncWithAxis = chart.yAxes.getIndex(0);
       } */
      valueAxis.min = 0;
      valueAxis.renderer.opposite = true;
      valueAxis.renderer.grid.template.disabled = true;
      valueAxis.title.text = '[bold] Triage latency (in days)';
      valueAxis.renderer.labels.template.fill = am4core.color("#000000");
      valueAxis.renderer.labels.template.fontSize = 12;
      valueAxis.renderer.line.strokeOpacity = 1;
      valueAxis.renderer.line.strokeWidth = 1;
      valueAxis.renderer.line.stroke = am4core.color("#e91e63");
      valueAxis.renderer.labels.template.fill = am4core.color("#e91e63");
      /* valueAxis.renderer.minGridDistance = 30; */

      var lineSeries = chart.series.push(new am4charts.LineSeries());
      lineSeries.name = "Triage latency (in days)";
      lineSeries.dataFields.valueY = "triageLatency";
      lineSeries.dataFields.categoryX = "chartType";
      lineSeries.yAxis = valueAxis;
      lineSeries.id = 'g1';
      lineSeries.stroke = am4core.color("#e91e63"); // yellow
      lineSeries.strokeWidth = 2;
      lineSeries.propertyFields.strokeDasharray = "lineDash";
      lineSeries.tooltip.label.textAlign = "middle";

      var bullet = lineSeries.bullets.push(new am4charts.Bullet());
      bullet.fill = am4core.color("#e91e63"); // tooltips grab fill from parent by default
      // bullet.tooltipText = "[#fff font-size: 15px]{name} in {categoryX}:\n[/][#fff font-size: 20px]{valueY}[/] [#fff]{additional}[/]"
      bullet.tooltipText = "[#fff font-size: 15px]{categoryX} : [/][#fff font-size: 15px]{valueY}[/] [#fff]{additional}[/]";
      var circle = bullet.createChild(am4core.Circle);
      circle.radius = 3;
      circle.fill = am4core.color("#fff");
      circle.strokeWidth = 2;
    }

  
    createTraigeLineSeries("cummClosedCount", "Cumulative Closed Sightings");
    createTraigeLineSeries("cummOpenCount", "Cumulative Closed Defect");
    createTraigeLineSeries("cummSubmittedCount", "Cumulative Submitted Sightings");

    TraigeLineSeries();

    chart.legend = new am4charts.Legend();
    chart.legend.position = "bottom";
    chart.legend.contentAlign = "center";
    chart.cursor = new am4charts.XYCursor();

    chart.scrollbarX = new am4core.Scrollbar();
    chart.scrollbarX.parent = chart.bottomAxesContainer;

    // if (this.duration == 'Week' || this.duration == 'Quarter') {
    //   chart.scrollbarX = new am4core.Scrollbar();
    //   chart.scrollbarX.parent = chart.bottomAxesContainer;
    //   zoomAxis();
    // }
    // if (this.duration == 'Quarter') {
    //   chart.scrollbarX = new am4core.Scrollbar();
    //   chart.scrollbarX.parent = chart.bottomAxesContainer;
    //   zoomAxisQuarter();
    // }
    // if (this.duration == 'Year') {
    //   chart.scrollbarX = new am4core.Scrollbar();
    //   chart.scrollbarX.parent = chart.bottomAxesContainer;
    // }
    function zoomAxisQuarter() {
      xAxis.start = 0.8;
      xAxis.end = 1;
      // categoryAxis.keepSelection = true;
    }
    function zoomAxis() {
      xAxis.start = 0.97;
      xAxis.end = 1;
      // categoryAxis.keepSelection = true;
    }
  }

  openSightingTrend(dataGetSightingsInfo) {
    am4core.useTheme(am4themes_animated);
    am4core.options.autoSetClassName = true;
    am4core.options.commercialLicense = true;
    // Themes end

    let chart = am4core.create("openSightingchart", am4charts.XYChart);
    chart.hiddenState.properties.opacity = 0; // this creates initial fade-in

    chart.data = dataGetSightingsInfo;

    chart.colors.step = 2;
    chart.padding(30, 30, 10, 30);
    chart.legend = new am4charts.Legend();
    //Change the lable rotation
    let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
    categoryAxis.dataFields.category = "domain";
    categoryAxis.renderer.grid.template.location = 0;
    categoryAxis.events.on("sizechanged", function (ev) {
      var axis = ev.target;
      var cellWidth = axis.pixelWidth / (axis.endIndex - axis.startIndex);
      if (cellWidth < axis.renderer.labels.template.maxWidth) {
        axis.renderer.labels.template.rotation = -45;
        axis.renderer.labels.template.horizontalCenter = "right";
        axis.renderer.labels.template.verticalCenter = "middle";
      }
      else {
        axis.renderer.labels.template.rotation = 0;
        axis.renderer.labels.template.horizontalCenter = "middle";
        axis.renderer.labels.template.verticalCenter = "top";
      }
    });


    let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
    valueAxis.min = 0;
    valueAxis.max = 30;
    valueAxis.strictMinMax = true;
    valueAxis.calculateTotals = true;
    valueAxis.renderer.minWidth = 50;

    let series1 = chart.series.push(new am4charts.ColumnSeries());
    series1.columns.template.width = am4core.percent(80);
    series1.columns.template.tooltipText =
      "{name}: {valueY}";
    series1.name = "Critical";
    series1.dataFields.categoryX = "domain";
    series1.dataFields.valueY = "critical";
    //series3.dataFields.valueYShow = "totalPercent";
    series1.dataItems.template.locations.categoryX = 0.5;
    series1.stacked = true;
    series1.tooltip.pointerOrientation = "vertical";
    series1.columns.template.stroke = am4core.color("#FF5733");
    series1.columns.template.fill = am4core.color("#FF5733");


    let bullet1 = series1.bullets.push(new am4charts.LabelBullet());
    bullet1.interactionsEnabled = false;
    bullet1.label.text = "{valueY}";
    bullet1.locationY = 0.5;
    bullet1.label.fill = am4core.color("#ffffff");


    let series2 = chart.series.push(new am4charts.ColumnSeries());
    series2.columns.template.width = am4core.percent(80);
    series2.columns.template.tooltipText =
      "{name}: {valueY}";
    series2.name = "High";
    series2.dataFields.categoryX = "domain";
    series2.dataFields.valueY = "high";
    //series1.dataFields.valueYShow = "totalPercent";
    series2.dataItems.template.locations.categoryX = 0.5;
    series2.stacked = true;
    series2.tooltip.pointerOrientation = "vertical";
    series2.columns.template.stroke = am4core.color("#E3AF05");
    series2.columns.template.fill = am4core.color("#E3AF05");

    let bullet2 = series2.bullets.push(new am4charts.LabelBullet());
    bullet2.interactionsEnabled = false;
    bullet2.label.text = "{valueY}";
    bullet2.label.fill = am4core.color("#ffffff");
    bullet2.locationY = 0.5;


    let series3 = chart.series.push(new am4charts.ColumnSeries());
    series3.columns.template.width = am4core.percent(80);
    series3.columns.template.tooltipText =
      "{name}: {valueY}";
    series3.name = "Medium";
    series3.dataFields.categoryX = "domain";
    series3.dataFields.valueY = "medium";
    //series2.dataFields.valueYShow = "totalPercent";
    series3.dataItems.template.locations.categoryX = 0.5;
    series3.stacked = true;
    series3.tooltip.pointerOrientation = "vertical";
    series3.columns.template.stroke = am4core.color("#F4E607");
    series3.columns.template.fill = am4core.color("#F4E607");

    let bullet3 = series3.bullets.push(new am4charts.LabelBullet());
    bullet3.interactionsEnabled = false;
    bullet3.label.text = "{valueY}";
    bullet3.locationY = 0.5;
    bullet3.label.fill = am4core.color("#ffffff");


    let series4 = chart.series.push(new am4charts.ColumnSeries());
    series4.columns.template.width = am4core.percent(80);
    series4.columns.template.tooltipText =
      "{name}: {valueY}";
    series4.name = "Low";
    series4.dataFields.categoryX = "domain";
    series4.dataFields.valueY = "low";
    series4.dataFields.valueYShow = "totalPercent";
    series4.dataItems.template.locations.categoryX = 0.5;
    series4.stacked = true;
    series4.tooltip.pointerOrientation = "vertical";
    series4.columns.template.stroke = am4core.color("blue");
    series4.columns.template.fill = am4core.color("blue");

    let bullet4 = series4.bullets.push(new am4charts.LabelBullet());
    bullet4.interactionsEnabled = false;
    bullet4.label.text = "{valueY}";
    bullet4.locationY = 0.5;
    bullet4.label.fill = am4core.color("#ffffff");

    chart.scrollbarX = new am4core.Scrollbar();
  }

}
