import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { environment } from '.././environments/environment';
import { Observable } from 'rxjs';

// import { Observable, throwError } from 'rxjs';
// import { catchError, retry } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ServiceAPIService {

  private API_URL= environment.API_URL;

  constructor(private http : HttpClient) { }

  getUserDetails(){
    return this.http.get('https://sivindicator.intel.com/cqiapi/api/Account/GetUser', {withCredentials: true});
  }
  getDD(){
    return this.http.post(this.API_URL+'GetMenu', {}, {withCredentials: true});
  }

  getOpenCloseTrendInfo(body){
    return this.http.post(this.API_URL + 'GetOpenCloseTrend', body, {withCredentials: true})
  }

  getOpenSightingsByDomainAndExposure(){
    return this.http.post(this.API_URL + 'GetOpenSightingsByDomainAndExposure', {}, {withCredentials: true})
  }

  getActiveCount(){
    return this.http.post(this.API_URL + 'GetActiveCount', {}, {withCredentials: true})
  }

  getClosedCount(){
    return this.http.post(this.API_URL + 'GetClosedCount', {}, {withCredentials: true})
  }

 // https://sivindicator.intel.com/SysdebugAPI/api/SIVSysDebug/GetActiveCount  GetClosedCount
}
