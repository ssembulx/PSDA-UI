import { any } from '@amcharts/amcharts4/.internal/core/utils/Array';
import { Component, OnInit } from '@angular/core';
import{ServiceAPIService} from '../service-api.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  userDetails : any;
  appBaseName = "SYS Debug Report Generator";
  appTitleBar: string;
  ddList: any;
  constructor(private apiService : ServiceAPIService) { }

  ngOnInit(): void {

    this.appTitleBar = this.appBaseName;

    this.apiService.getUserDetails().subscribe(res=>{
      console.log(res);
      this.userDetails = res;
    })
    this.apiService.getDD().subscribe((res:any)=>{
      console.log(res);
      this.ddList = res.getmenu;
    
    })
  
  }

}
